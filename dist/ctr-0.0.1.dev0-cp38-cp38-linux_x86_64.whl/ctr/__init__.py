from .ctr import alternating_least_squares

__version__ = '0.0.1.dev0'

__all__ = [alternating_least_squares, __version__]
